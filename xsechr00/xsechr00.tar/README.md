Spuštění:
	./mytftpclient


Chybějicí implementace:
	timeout interval
	multicast option