Spuštění:
	./mytftpclient


Chybějicí implementace:
	timeout interval
	multicast option
	
-s blocksize option
	Velikost hlídám v parsovácí funkci a data ukládám do bufferu velikost 1500 		octetů, což vím, že mi bude vždycky stačit a pak je posílám do souboru nebo
	na server podle zadaného parametru